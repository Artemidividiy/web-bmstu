# frozen_string_literal: true

require './part_2'

d1 = Dot.new(0.1, 0.5)
d2 = Dot.new(0, 3)
puts d1
puts d2

c = Circle.new(d1, 10)
puts c
