# frozen_string_literal: true

require './part_2'

sol = Solution.new
puts sol.calculate(gets)
