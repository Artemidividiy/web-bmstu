# frozen_string_literal: true

require './part_1'

puts calculate(gets)
