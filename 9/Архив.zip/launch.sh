cd armstrong
rails s